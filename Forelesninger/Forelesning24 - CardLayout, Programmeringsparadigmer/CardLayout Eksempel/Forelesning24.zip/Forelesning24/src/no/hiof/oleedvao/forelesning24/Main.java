package no.hiof.oleedvao.forelesning24;

import no.hiof.oleedvao.forelesning24.forms.CardLayoutGUI;

public class Main {
    public static void main(String[] args) {
        CardLayoutGUI cardLayoutGUI = new CardLayoutGUI("Card Layout");
        cardLayoutGUI.setVisible(true);
    }
}
