package no.hiof.oleedvao.forelesning22;

import no.hiof.oleedvao.forelesning22.forms.CreatePersonGUI;

public class CreatePersonMain{
    public static void main(String[] args) {
        CreatePersonGUI createPersonGUI = new CreatePersonGUI("Create Person");
        createPersonGUI.setVisible(true);
    }
}
