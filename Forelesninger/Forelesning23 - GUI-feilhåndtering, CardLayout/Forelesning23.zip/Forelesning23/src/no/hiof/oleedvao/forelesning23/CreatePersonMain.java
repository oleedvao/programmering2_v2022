package no.hiof.oleedvao.forelesning23;

import no.hiof.oleedvao.forelesning23.forms.CreatePersonGUI;

public class CreatePersonMain {
    public static void main(String[] args) {
        CreatePersonGUI createPersonGUI = new CreatePersonGUI("Create Person");
        createPersonGUI.setVisible(true);
    }
}
