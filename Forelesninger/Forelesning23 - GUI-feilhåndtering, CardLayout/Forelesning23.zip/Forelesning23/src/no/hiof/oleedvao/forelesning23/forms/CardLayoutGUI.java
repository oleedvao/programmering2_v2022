package no.hiof.oleedvao.forelesning23.forms;

import javax.swing.*;

public class CardLayoutGUI {
    private JPanel mainPanel;
    private JPanel cardLayoutPanel;
    private JButton navigateToPage2Button;
    private JPanel page1Panel;
    private JPanel page2Panel;
    private JButton navigateToPage1Button;
}
